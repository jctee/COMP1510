John Tee, A00973875, Set D, October 8 2016

This assignment is 100% complete.


------------------------
Question one (Change) status:

COMPLETE

------------------------
Question two (SecondsConvert) status:

COMPLETE

------------------------
Question three (Arithmetic) status:

COMPLETE

------------------------
Question four (Cube) status:

COMPLETE

------------------------
Question five (Pie Chart) status:

COMPLETE
